package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.entidade.Livro;
import model.enums.StatusLivro;
import util.ConnectionFactory;

/**
 *
 * @author DINIZ
 */

public class LivroDAO {

    private Connection getConexao() throws SQLException {
        return ConnectionFactory.getConnection();
    }

    public void cadastrar(Livro livro) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
                "INSERT INTO livros (titulo, autor, editora, isbn, genero, "
                + "ano_publicacao, numero_paginas, idioma, preco, quantidade, status) "
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?)"
        );
        cmd.setString(1, livro.getTitulo());
        cmd.setString(2, livro.getAutor());
        cmd.setString(3, livro.getEditora());
        cmd.setString(4, livro.getIsbn());
        cmd.setString(5, livro.getGenero());
        cmd.setInt(6, livro.getAnoPublicacao());
        cmd.setInt(7, livro.getNumeroPaginas());
        cmd.setString(8, livro.getIdioma());
        cmd.setDouble(9, livro.getPreco());
        cmd.setInt(10, livro.getQuantidade());
        cmd.setString(11, livro.getStatus().name());
        cmd.execute();
        con.close();
    }

    public void deletar(Livro livro) throws SQLException {
        Connection con = getConexao();
        try {
            con.setAutoCommit(false);
            // Remove histórico de empréstimos primeiro para respeitar a FK
            PreparedStatement cmdEmp = con.prepareStatement(
                "DELETE FROM emprestimos WHERE id_livro = ?"
            );
            cmdEmp.setInt(1, livro.getId());
            cmdEmp.execute();
            // Agora deleta o livro
            PreparedStatement cmdLivro = con.prepareStatement(
                "DELETE FROM livros WHERE id = ?"
            );
            cmdLivro.setInt(1, livro.getId());
            cmdLivro.execute();
            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
            con.close();
        }
    }

    public void atualizar(Livro livro) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
                "UPDATE livros SET titulo=?, autor=?, editora=?, isbn=?, genero=?, "
                + "ano_publicacao=?, numero_paginas=?, idioma=?, preco=?, quantidade=?, status=? "
                + "WHERE id=?"
        );
        cmd.setString(1, livro.getTitulo());
        cmd.setString(2, livro.getAutor());
        cmd.setString(3, livro.getEditora());
        cmd.setString(4, livro.getIsbn());
        cmd.setString(5, livro.getGenero());
        cmd.setInt(6, livro.getAnoPublicacao());
        cmd.setInt(7, livro.getNumeroPaginas());
        cmd.setString(8, livro.getIdioma());
        cmd.setDouble(9, livro.getPreco());
        cmd.setInt(10, livro.getQuantidade());
        cmd.setString(11, livro.getStatus().name());
        cmd.setInt(12, livro.getId());
        cmd.execute();
        con.close();
    }

    public Livro consultarPorId(int id) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
                "SELECT * FROM livros WHERE id = ?"
        );
        cmd.setInt(1, id);
        ResultSet rs = cmd.executeQuery();
        Livro livro = null;
        if (rs.next()) {
            livro = new Livro.LivroBuilder()
                    .comId(rs.getInt("id"))
                    .comTitulo(rs.getString("titulo"))
                    .comAutor(rs.getString("autor"))
                    .comEditora(rs.getString("editora"))
                    .comIsbn(rs.getString("isbn"))
                    .comGenero(rs.getString("genero"))
                    .comAnoPublicacao(rs.getInt("ano_publicacao"))
                    .comNumeroPaginas(rs.getInt("numero_paginas"))
                    .comIdioma(rs.getString("idioma"))
                    .comPreco(rs.getDouble("preco"))
                    .comQuantidade(rs.getInt("quantidade"))
                    .comStatus(StatusLivro.valueOf(rs.getString("status")))
                    .build();
        }
        con.close();
        return livro;
    }

    public List<Livro> consultarTodos() throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement("SELECT * FROM livros");
        ResultSet rs = cmd.executeQuery();
        List<Livro> lista = new ArrayList<>();
        while (rs.next()) {
            Livro livro = new Livro.LivroBuilder()
                    .comId(rs.getInt("id"))
                    .comTitulo(rs.getString("titulo"))
                    .comAutor(rs.getString("autor"))
                    .comEditora(rs.getString("editora"))
                    .comIsbn(rs.getString("isbn"))
                    .comGenero(rs.getString("genero"))
                    .comAnoPublicacao(rs.getInt("ano_publicacao"))
                    .comNumeroPaginas(rs.getInt("numero_paginas"))
                    .comIdioma(rs.getString("idioma"))
                    .comPreco(rs.getDouble("preco"))
                    .comQuantidade(rs.getInt("quantidade"))
                    .comStatus(StatusLivro.valueOf(rs.getString("status")))
                    .build();
            lista.add(livro);
        }
        con.close();
        return lista;
    }
}
