package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.entidade.Usuario;
import model.enums.TipoUsuario;
import util.ConnectionFactory;

/**
 *
 * @author DINIZ
 */

public class UsuarioDAO {

    private Connection getConexao() throws SQLException {
        return ConnectionFactory.getConnection();
    }

    public void cadastrar(Usuario usuario) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "INSERT INTO usuarios (nome, email, senha, tipo, ativo) VALUES (?,?,?,?,?)"
        );
        cmd.setString(1, usuario.getNome());
        cmd.setString(2, usuario.getEmail());
        cmd.setString(3, usuario.getSenha());
        cmd.setString(4, usuario.getTipo().name());
        cmd.setBoolean(5, usuario.isAtivo());
        cmd.execute();
        con.close();
    }

    public void deletar(Usuario usuario) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "DELETE FROM usuarios WHERE id = ?"
        );
        cmd.setInt(1, usuario.getId());
        cmd.execute();
        con.close();
    }

    public void atualizar(Usuario usuario) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "UPDATE usuarios SET nome=?, email=?, senha=?, tipo=?, ativo=? WHERE id=?"
        );
        cmd.setString(1, usuario.getNome());
        cmd.setString(2, usuario.getEmail());
        cmd.setString(3, usuario.getSenha());
        cmd.setString(4, usuario.getTipo().name());
        cmd.setBoolean(5, usuario.isAtivo());
        cmd.setInt(6, usuario.getId());
        cmd.execute();
        con.close();
    }

    public Usuario consultarPorId(int id) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "SELECT * FROM usuarios WHERE id = ?"
        );
        cmd.setInt(1, id);
        ResultSet rs = cmd.executeQuery();
        Usuario usuario = null;
        if (rs.next()) {
            usuario = new Usuario(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("email"),
                rs.getString("senha"),
                TipoUsuario.valueOf(rs.getString("tipo")),
                rs.getBoolean("ativo")
            );
        }
        con.close();
        return usuario;
    }

    public List<Usuario> consultarTodos() throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement("SELECT * FROM usuarios");
        ResultSet rs = cmd.executeQuery();
        List<Usuario> lista = new ArrayList<>();
        while (rs.next()) {
            lista.add(new Usuario(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("email"),
                rs.getString("senha"),
                TipoUsuario.valueOf(rs.getString("tipo")),
                rs.getBoolean("ativo")
            ));
        }
        con.close();
        return lista;
    }
    
    public Usuario consultarPorEmailSenha(String email, String senha) throws SQLException {
    Connection con = getConexao();
    PreparedStatement cmd = con.prepareStatement(
        "SELECT * FROM usuarios WHERE email = ? AND senha = ? AND ativo = true"
    );
    cmd.setString(1, email);
    cmd.setString(2, senha);
    ResultSet rs = cmd.executeQuery();
    Usuario usuario = null;
    if (rs.next()) {
        usuario = new Usuario(
            rs.getInt("id"),
            rs.getString("nome"),
            rs.getString("email"),
            rs.getString("senha"),
            TipoUsuario.valueOf(rs.getString("tipo")),
            rs.getBoolean("ativo")
        );
    }
    con.close();
    return usuario;
}
}