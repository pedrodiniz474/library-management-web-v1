package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.entidade.Emprestimo;
import model.entidade.Livro;
import model.entidade.Usuario;
import util.ConnectionFactory;

/**
 *
 * @author DINIZ
 */

public class EmprestimoDAO {

    private Connection getConexao() throws SQLException {
        return ConnectionFactory.getConnection();
    }

    public void cadastrar(Emprestimo emp) throws SQLException {
        Connection con = getConexao();
        try {
            con.setAutoCommit(false);

            // 1. Inserir o empréstimo
            PreparedStatement cmdEmp = con.prepareStatement(
                "INSERT INTO emprestimos (id_usuario, id_livro, data_emprestimo, " +
                "data_prevista_devolucao, data_devolucao) VALUES (?,?,?,?,?)"
            );
            cmdEmp.setInt(1, emp.getUsuario().getId());
            cmdEmp.setInt(2, emp.getLivro().getId());
            cmdEmp.setDate(3, Date.valueOf(emp.getDataEmprestimo()));
            cmdEmp.setDate(4, Date.valueOf(emp.getDataPrevistaDevolucao()));
            cmdEmp.setDate(5, emp.getDataDevolucao() != null
                    ? Date.valueOf(emp.getDataDevolucao()) : null);
            cmdEmp.execute();

            // 2. Diminuir quantidade — status só muda pra EMPRESTADO quando zera
            PreparedStatement cmdLivro = con.prepareStatement(
                "UPDATE livros SET " +
                "quantidade = quantidade - 1, " +
                "status = CASE WHEN (quantidade - 1) <= 0 THEN 'EMPRESTADO' ELSE 'DISPONIVEL' END " +
                "WHERE id = ? AND quantidade > 0"
            );
            cmdLivro.setInt(1, emp.getLivro().getId());
            int linhasAfetadas = cmdLivro.executeUpdate();
            if (linhasAfetadas == 0) {
                con.rollback();
                throw new SQLException("Livro indisponível para empréstimo.");
            }

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
            con.close();
        }
    }

    public void deletar(Emprestimo emp) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "DELETE FROM emprestimos WHERE id = ?"
        );
        cmd.setInt(1, emp.getId());
        cmd.execute();
        con.close();
    }

    public void atualizar(Emprestimo emp) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "UPDATE emprestimos SET id_usuario=?, id_livro=?, data_emprestimo=?, " +
            "data_prevista_devolucao=?, data_devolucao=? WHERE id=?"
        );
        cmd.setInt(1, emp.getUsuario().getId());
        cmd.setInt(2, emp.getLivro().getId());
        cmd.setDate(3, Date.valueOf(emp.getDataEmprestimo()));
        cmd.setDate(4, Date.valueOf(emp.getDataPrevistaDevolucao()));
        cmd.setDate(5, emp.getDataDevolucao() != null
                ? Date.valueOf(emp.getDataDevolucao()) : null);
        cmd.setInt(6, emp.getId());
        cmd.execute();
        con.close();
    }

    public Emprestimo consultarPorId(int id) throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "SELECT e.*, " +
            "u.id as u_id, u.nome, u.email, u.senha, u.tipo, u.ativo, " +
            "l.id as l_id, l.titulo, l.autor, l.editora, l.isbn, l.genero, " +
            "l.ano_publicacao, l.numero_paginas, l.idioma, l.preco, l.quantidade, l.status " +
            "FROM emprestimos e " +
            "JOIN usuarios u ON e.id_usuario = u.id " +
            "JOIN livros l ON e.id_livro = l.id " +
            "WHERE e.id = ?"
        );
        cmd.setInt(1, id);
        ResultSet rs = cmd.executeQuery();
        Emprestimo emp = null;
        if (rs.next()) {
            emp = montarEmprestimo(rs);
        }
        con.close();
        return emp;
    }

    public List<Emprestimo> consultarTodos() throws SQLException {
        Connection con = getConexao();
        PreparedStatement cmd = con.prepareStatement(
            "SELECT e.*, " +
            "u.id as u_id, u.nome, u.email, u.senha, u.tipo, u.ativo, " +
            "l.id as l_id, l.titulo, l.autor, l.editora, l.isbn, l.genero, " +
            "l.ano_publicacao, l.numero_paginas, l.idioma, l.preco, l.quantidade, l.status " +
            "FROM emprestimos e " +
            "JOIN usuarios u ON e.id_usuario = u.id " +
            "JOIN livros l ON e.id_livro = l.id"
        );
        ResultSet rs = cmd.executeQuery();
        List<Emprestimo> lista = new ArrayList<>();
        while (rs.next()) {
            lista.add(montarEmprestimo(rs));
        }
        con.close();
        return lista;
    }

    // --- processo de negócio: registrar devolução e calcular multa ---
    public double registrarDevolucao(int idEmprestimo) throws SQLException {
        Emprestimo emp = consultarPorId(idEmprestimo);
        if (emp == null) throw new SQLException("Empréstimo não encontrado.");

        Emprestimo empAtualizado = new Emprestimo.EmprestimoBuilder()
            .comId(emp.getId())
            .comUsuario(emp.getUsuario())
            .comLivro(emp.getLivro())
            .comDataEmprestimo(emp.getDataEmprestimo())
            .comDataPrevistaDevolucao(emp.getDataPrevistaDevolucao())
            .comDataDevolucao(java.time.LocalDate.now())
            .build();

        Connection con = getConexao();
        try {
            con.setAutoCommit(false);

            // 1. Registrar data de devolução no empréstimo
            PreparedStatement cmdEmp = con.prepareStatement(
                "UPDATE emprestimos SET data_devolucao=? WHERE id=?"
            );
            cmdEmp.setDate(1, Date.valueOf(empAtualizado.getDataDevolucao()));
            cmdEmp.setInt(2, empAtualizado.getId());
            cmdEmp.executeUpdate();

            // 2. Devolver quantidade ao livro e recolocar como DISPONIVEL
            PreparedStatement cmdLivro = con.prepareStatement(
                "UPDATE livros SET quantidade = quantidade + 1, status = 'DISPONIVEL' WHERE id = ?"
            );
            cmdLivro.setInt(1, emp.getLivro().getId());
            cmdLivro.executeUpdate();

            con.commit();
        } catch (SQLException ex) {
            con.rollback();
            throw ex;
        } finally {
            con.setAutoCommit(true);
            con.close();
        }

        return empAtualizado.calcularMulta();
    }

    // --- método auxiliar privado para montar o objeto do ResultSet ---
    private Emprestimo montarEmprestimo(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario(
            rs.getInt("u_id"),
            rs.getString("nome"),
            rs.getString("email"),
            rs.getString("senha"),
            model.enums.TipoUsuario.valueOf(rs.getString("tipo")),
            rs.getBoolean("ativo")
        );

        Livro livro = new Livro.LivroBuilder()
            .comId(rs.getInt("l_id"))
            .comTitulo(rs.getString("titulo"))
            .comAutor(rs.getString("autor"))
            .comEditora(rs.getString("editora"))
            .comIsbn(rs.getString("isbn"))
            .comGenero(rs.getString("genero"))
            .comAnoPublicacao(rs.getInt("ano_publicacao"))
            .comNumeroPaginas(rs.getInt("numero_paginas"))
            .comIdioma(rs.getString("idioma"))
            .comPreco(rs.getDouble("preco"))
            .comQuantidade(rs.getInt("quantidade"))
            .comStatus(model.enums.StatusLivro.valueOf(rs.getString("status")))
            .build();

        Date dataDev = rs.getDate("data_devolucao");

        return new Emprestimo.EmprestimoBuilder()
            .comId(rs.getInt("id"))
            .comUsuario(usuario)
            .comLivro(livro)
            .comDataEmprestimo(rs.getDate("data_emprestimo").toLocalDate())
            .comDataPrevistaDevolucao(rs.getDate("data_prevista_devolucao").toLocalDate())
            .comDataDevolucao(dataDev != null ? dataDev.toLocalDate() : null)
            .build();
    }
}