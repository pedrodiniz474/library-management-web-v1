/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.entidade;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import model.service.CalculadoraMulta;

/**
 *
 * @author DINIZ
 */
public class Emprestimo {

    private static final double MULTA_POR_DIA = 1.00;

    private int id;
    private Usuario usuario;
    private Livro livro;
    private LocalDate dataEmprestimo;
    private LocalDate dataPrevistaDevolucao;
    private LocalDate dataDevolucao;

    private Emprestimo(EmprestimoBuilder builder) {
        this.id = builder.id;
        this.livro = builder.livro;
        this.usuario = builder.usuario;
        this.dataEmprestimo = builder.dataEmprestimo;
        this.dataPrevistaDevolucao = builder.dataPrevistaDevolucao;
        this.dataDevolucao = builder.dataDevolucao;
    }

    public int getId() {
        return id;
    }

    public Livro getLivro() {
        return livro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public LocalDate getDataPrevistaDevolucao() {
        return dataPrevistaDevolucao;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }
    
    // calcular dias de atraso
    public int calcularDiasAtraso(){
        LocalDate dataFinal;
        
        if (dataDevolucao !=null) {
            dataFinal = dataDevolucao;
        } else {
            dataFinal = LocalDate.now();
        }
        
        if (dataFinal.isAfter(dataPrevistaDevolucao)) {
            return (int) ChronoUnit.DAYS.between(dataPrevistaDevolucao, dataFinal); 
        }
        
        return 0;
    }
    
    // calcular multa
    public double calcularMulta(){
        int diasAtraso = calcularDiasAtraso();
        return CalculadoraMulta.calcular(diasAtraso);
    }

    public static class EmprestimoBuilder {

        private int id;
        private Usuario usuario;
        private Livro livro;
        private LocalDate dataEmprestimo;
        private LocalDate dataPrevistaDevolucao;
        private LocalDate dataDevolucao;

        public EmprestimoBuilder comId(int id) {
            this.id = id;
            return this;
        }

        public EmprestimoBuilder comLivro(Livro livro) {
            this.livro = livro;
            return this;
        }

        public EmprestimoBuilder comUsuario(Usuario usuario) {
            this.usuario = usuario;
            return this;
        }

        public EmprestimoBuilder comDataEmprestimo(LocalDate dataEmprestimo) {
            this.dataEmprestimo = dataEmprestimo;
            return this;
        }

        public EmprestimoBuilder comDataPrevistaDevolucao(LocalDate dataPrevistaDevolucao) {
            this.dataPrevistaDevolucao = dataPrevistaDevolucao;
            return this;
        }

        public EmprestimoBuilder comDataDevolucao(LocalDate dataDevolucao) {
            this.dataDevolucao = dataDevolucao;
            return this;
        }

        public Emprestimo build() {
            return new Emprestimo(this);
        }
    }

}
