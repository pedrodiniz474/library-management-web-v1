package controller;

import dao.EmprestimoDAO;
import dao.LivroDAO;
import dao.UsuarioDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.entidade.Emprestimo;
import model.entidade.Livro;
import model.entidade.Usuario;

@WebServlet(name = "ManterEmprestimo", urlPatterns = {"/ManterEmprestimo"})
public class ManterEmprestimo extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect("index.jsp");
            return;
        }
        Usuario logado = (Usuario) session.getAttribute("usuarioLogado");
        if (logado == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        boolean isAdmin = logado.getTipo().name().equals("ADMIN");
        String msg = "";
        String op = request.getParameter("btnop");
        EmprestimoDAO dao = new EmprestimoDAO();

        if (op.equals("CADASTRAR")) {
            try {
                int idUsuario  = Integer.parseInt(request.getParameter("txtidUsuario"));
                int idLivro    = Integer.parseInt(request.getParameter("txtidLivro"));
                LocalDate dataEmp  = LocalDate.now();
                LocalDate dataPrev = dataEmp.plusDays(15);

                Usuario usuario = new UsuarioDAO().consultarPorId(idUsuario);
                Livro livro     = new LivroDAO().consultarPorId(idLivro);

                if (usuario == null) {
                    msg = "Erro: usuário não encontrado.";
                } else if (livro == null) {
                    msg = "Erro: livro não encontrado.";
                } else {
                    // --- VERIFICAR MULTA PENDENTE ---
                    // Percorre todos os empréstimos do usuário; se houver algum
                    // não devolvido com atraso, bloqueia e exibe o valor total da multa.
                    java.util.List<Emprestimo> todosEmp = dao.consultarTodos();
                    double multaPendente = 0;
                    for (Emprestimo e : todosEmp) {
                        if (e.getUsuario().getId() == idUsuario
                                && e.getDataDevolucao() == null
                                && e.calcularDiasAtraso() > 0) {
                            multaPendente += e.calcularMulta();
                        }
                    }
                    if (multaPendente > 0) {
                        msg = "Bloqueado: você possui multa pendente de R$ "
                            + String.format("%.2f", multaPendente)
                            + ". Devolva o(s) livro(s) em atraso e quite a multa antes de realizar novos empréstimos.";
                    } else {
                        dao.cadastrar(new Emprestimo.EmprestimoBuilder()
                            .comUsuario(usuario).comLivro(livro)
                            .comDataEmprestimo(dataEmp)
                            .comDataPrevistaDevolucao(dataPrev)
                            .build());
                        msg = "Empréstimo realizado! Devolva o livro até " + dataPrev + ".";
                    }
                }
            } catch (SQLException ex) {
                msg = "Erro ao cadastrar empréstimo: " + ex.getMessage();
            } catch (NumberFormatException ex) {
                msg = "Erro: ID inválido.";
            }

        } else if (op.equals("DELETAR")) {
            if (!isAdmin) { response.sendRedirect("home.jsp"); return; }
            try {
                int id = Integer.parseInt(request.getParameter("txtid"));
                dao.deletar(new Emprestimo.EmprestimoBuilder().comId(id).build());
                msg = "Empréstimo excluído com sucesso.";
            } catch (SQLException | NumberFormatException ex) {
                msg = "Erro ao excluir: " + ex.getMessage();
            }

        } else if (op.equals("ATUALIZAR")) {
            if (!isAdmin) { response.sendRedirect("home.jsp"); return; }
            try {
                int idUsuario = Integer.parseInt(request.getParameter("txtidUsuario"));
                int idLivro   = Integer.parseInt(request.getParameter("txtidLivro"));
                LocalDate dataEmp  = LocalDate.parse(request.getParameter("txtdataEmprestimo"));
                LocalDate dataPrev = LocalDate.parse(request.getParameter("txtdataPrevista"));
                Usuario usuario = new UsuarioDAO().consultarPorId(idUsuario);
                Livro livro     = new LivroDAO().consultarPorId(idLivro);
                dao.atualizar(new Emprestimo.EmprestimoBuilder()
                    .comId(Integer.parseInt(request.getParameter("txtid")))
                    .comUsuario(usuario).comLivro(livro)
                    .comDataEmprestimo(dataEmp)
                    .comDataPrevistaDevolucao(dataPrev)
                    .build());
                msg = "Empréstimo atualizado com sucesso.";
            } catch (SQLException | NumberFormatException ex) {
                msg = "Erro ao atualizar: " + ex.getMessage();
            }

        } else if (op.equals("DEVOLVER")) {
            try {
                int id = Integer.parseInt(request.getParameter("txtid"));
                double multa = dao.registrarDevolucao(id);
                msg = multa > 0
                    ? "Devolução registrada com atraso. Multa: R$ " + String.format("%.2f", multa)
                    : "Devolução registrada no prazo. Sem multa.";
            } catch (SQLException | NumberFormatException ex) {
                msg = "Erro ao registrar devolução: " + ex.getMessage();
            }
        }

        session.setAttribute("msg", msg);
        response.sendRedirect(isAdmin ? "emprestimos.jsp" : "home.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
    @Override
    public String getServletInfo() { return "Servlet ManterEmprestimo - BiblioTech"; }
}
