package controller;

import dao.UsuarioDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.entidade.Usuario;
import model.enums.TipoUsuario;
import util.HashUtil;

@WebServlet(name = "CadastroServlet", urlPatterns = {"/CadastroServlet"})
public class CadastroServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String nome  = request.getParameter("txtnome");
        String email = request.getParameter("txtemail");
        String senha = request.getParameter("txtsenha");

        if (nome == null || nome.trim().isEmpty()) {
            request.setAttribute("erro", "Preencha o campo Nome.");
            request.getRequestDispatcher("cadastro.jsp").forward(request, response);
            return;
        }
        if (email == null || email.trim().isEmpty()) {
            request.setAttribute("erro", "Preencha o campo Email.");
            request.getRequestDispatcher("cadastro.jsp").forward(request, response);
            return;
        }
        if (senha == null || senha.trim().isEmpty()) {
            request.setAttribute("erro", "Preencha o campo Senha.");
            request.getRequestDispatcher("cadastro.jsp").forward(request, response);
            return;
        }

        try {
            // sempre cria como USER — ADMIN só pode ser criado diretamente no banco
            String senhaHash = HashUtil.sha256(senha.trim());
            new UsuarioDAO().cadastrar(new Usuario(
                0, nome.trim(), email.trim(), senhaHash, TipoUsuario.USER, true
            ));
            request.getSession().setAttribute("msg", "Conta criada com sucesso! Faça login.");
            response.sendRedirect("index.jsp");
        } catch (SQLException ex) {
            request.setAttribute("erro", "Erro ao criar conta: " + ex.getMessage());
            request.getRequestDispatcher("cadastro.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
}
