package controller;

import dao.UsuarioDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.entidade.Usuario;
import model.enums.TipoUsuario;
import util.HashUtil;

@WebServlet(name = "ManterUsuario", urlPatterns = {"/ManterUsuario"})
public class ManterUsuario extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String msg = "";
        String op = request.getParameter("btnop");
        UsuarioDAO dao = new UsuarioDAO();

        if (op.equals("CADASTRAR")) {
            try {
                String senhaHash = HashUtil.sha256(request.getParameter("txtsenha").trim());
                Usuario usuario = new Usuario(
                    0,
                    request.getParameter("txtnome"),
                    request.getParameter("txtemail"),
                    senhaHash,
                    TipoUsuario.valueOf(request.getParameter("seltipo")),
                    true
                );
                dao.cadastrar(usuario);
                msg = "Usuário cadastrado com sucesso.";
            } catch (SQLException ex) {
                msg = "Erro ao cadastrar usuário: " + ex.getMessage();
            }

        } else if (op.equals("DELETAR")) {
            try {
                int id = Integer.parseInt(request.getParameter("txtid"));
                Usuario usuario = new Usuario();
                usuario.setId(id);
                dao.deletar(usuario);
                msg = "Usuário deletado com sucesso.";
            } catch (SQLException | NumberFormatException ex) {
                msg = "Erro ao deletar usuário: " + ex.getMessage();
            }

        } else if (op.equals("ATUALIZAR")) {
            try {
                int idUsuario = Integer.parseInt(request.getParameter("txtid"));
                String senhaDigitada = request.getParameter("txtsenha");
                String senhaFinal;
                if (senhaDigitada != null && !senhaDigitada.trim().isEmpty()) {
                    senhaFinal = HashUtil.sha256(senhaDigitada.trim());
                } else {
                    senhaFinal = dao.consultarPorId(idUsuario).getSenha();
                }
                Usuario usuario = new Usuario(
                    idUsuario,
                    request.getParameter("txtnome"),
                    request.getParameter("txtemail"),
                    senhaFinal,
                    TipoUsuario.valueOf(request.getParameter("seltipo")),
                    Boolean.parseBoolean(request.getParameter("chkativo"))
                );
                dao.atualizar(usuario);
                msg = "Usuário atualizado com sucesso.";
            } catch (SQLException | NumberFormatException ex) {
                msg = "Erro ao atualizar usuário: " + ex.getMessage();
            }
        }

        request.getSession().setAttribute("msg", msg);
        response.sendRedirect("usuarios.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }

    @Override
    public String getServletInfo() { return "Servlet ManterUsuario - BiblioTech"; }
}
