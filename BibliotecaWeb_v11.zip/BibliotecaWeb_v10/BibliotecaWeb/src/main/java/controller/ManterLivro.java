package controller;

import dao.LivroDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.entidade.Livro;
import model.enums.StatusLivro;

@WebServlet(name = "ManterLivro", urlPatterns = {"/ManterLivro"})
public class ManterLivro extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String msg = "";
        String op = request.getParameter("btnop");
        LivroDAO dao = new LivroDAO();

        if (op.equals("CADASTRAR")) {
            String titulo    = request.getParameter("txttitulo");
            String autor     = request.getParameter("txtautor");
            String anoStr    = request.getParameter("txtano");
            String paginasStr = request.getParameter("txtpaginas");
            String precoStr  = request.getParameter("txtpreco");
            String qtdStr    = request.getParameter("txtquantidade");

            if (titulo == null || titulo.trim().isEmpty()) {
                msg = "Erro: preencha o campo Título.";
            } else if (autor == null || autor.trim().isEmpty()) {
                msg = "Erro: preencha o campo Autor.";
            } else if (anoStr == null || anoStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Ano de Publicação.";
            } else if (paginasStr == null || paginasStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Número de Páginas.";
            } else if (precoStr == null || precoStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Preço.";
            } else if (qtdStr == null || qtdStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Quantidade.";
            } else {
                try {
                    int ano = Integer.parseInt(anoStr.trim());
                    int paginas = Integer.parseInt(paginasStr.trim());
                    double preco = Double.parseDouble(precoStr.trim().replace(",", "."));
                    int qtd = Integer.parseInt(qtdStr.trim());
                    if (ano <= 0) {
                        msg = "Erro: Ano de Publicação deve ser um valor positivo.";
                    } else if (paginas <= 0) {
                        msg = "Erro: Número de Páginas deve ser maior que zero.";
                    } else if (preco < 0) {
                        msg = "Erro: Preço não pode ser negativo.";
                    } else if (qtd <= 0) {
                        msg = "Erro: Quantidade deve ser maior que zero.";
                    } else {
                        Livro livro = new Livro.LivroBuilder()
                            .comTitulo(titulo.trim())
                            .comAutor(autor.trim())
                            .comEditora(request.getParameter("txteditora"))
                            .comIsbn(request.getParameter("txtisbn"))
                            .comGenero(request.getParameter("txtgenero"))
                            .comAnoPublicacao(ano)
                            .comNumeroPaginas(paginas)
                            .comIdioma(request.getParameter("txtidioma"))
                            .comPreco(preco)
                            .comQuantidade(qtd)
                            .comStatus(StatusLivro.valueOf(request.getParameter("selstatus")))
                            .build();
                        dao.cadastrar(livro);
                        msg = "Livro cadastrado com sucesso.";
                    }
                } catch (NumberFormatException ex) {
                    msg = "Erro: Ano, Páginas, Preço e Quantidade devem ser números válidos.";
                } catch (SQLException ex) {
                    msg = "Erro ao cadastrar livro: " + ex.getMessage();
                }
            }

        } else if (op.equals("DELETAR")) {
            String idStr = request.getParameter("txtid");
            if (idStr == null || idStr.trim().isEmpty()) {
                msg = "Erro: informe o ID do livro para excluir.";
            } else {
                try {
                    dao.deletar(new Livro.LivroBuilder().comId(Integer.parseInt(idStr.trim())).build());
                    msg = "Livro excluído com sucesso.";
                } catch (NumberFormatException ex) {
                    msg = "Erro: ID inválido.";
                } catch (SQLException ex) {
                    msg = "Erro ao excluir livro: " + ex.getMessage();
                }
            }

        } else if (op.equals("ATUALIZAR")) {
            String idStr     = request.getParameter("txtid");
            String titulo    = request.getParameter("txttitulo");
            String autor     = request.getParameter("txtautor");
            String anoStr    = request.getParameter("txtano");
            String paginasStr = request.getParameter("txtpaginas");
            String precoStr  = request.getParameter("txtpreco");
            String qtdStr    = request.getParameter("txtquantidade");

            if (idStr == null || idStr.trim().isEmpty()) {
                msg = "Erro: ID não informado para atualização.";
            } else if (titulo == null || titulo.trim().isEmpty()) {
                msg = "Erro: preencha o campo Título.";
            } else if (autor == null || autor.trim().isEmpty()) {
                msg = "Erro: preencha o campo Autor.";
            } else if (anoStr == null || anoStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Ano de Publicação.";
            } else if (paginasStr == null || paginasStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Número de Páginas.";
            } else if (precoStr == null || precoStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Preço.";
            } else if (qtdStr == null || qtdStr.trim().isEmpty()) {
                msg = "Erro: preencha o campo Quantidade.";
            } else {
                try {
                    int ano = Integer.parseInt(anoStr.trim());
                    int paginas = Integer.parseInt(paginasStr.trim());
                    double preco = Double.parseDouble(precoStr.trim().replace(",", "."));
                    int qtd = Integer.parseInt(qtdStr.trim());
                    if (ano <= 0) {
                        msg = "Erro: Ano de Publicação deve ser um valor positivo.";
                    } else if (paginas <= 0) {
                        msg = "Erro: Número de Páginas deve ser maior que zero.";
                    } else if (preco < 0) {
                        msg = "Erro: Preço não pode ser negativo.";
                    } else if (qtd <= 0) {
                        msg = "Erro: Quantidade deve ser maior que zero.";
                    } else {
                        Livro livro = new Livro.LivroBuilder()
                            .comId(Integer.parseInt(idStr.trim()))
                            .comTitulo(titulo.trim())
                            .comAutor(autor.trim())
                            .comEditora(request.getParameter("txteditora"))
                            .comIsbn(request.getParameter("txtisbn"))
                            .comGenero(request.getParameter("txtgenero"))
                            .comAnoPublicacao(ano)
                            .comNumeroPaginas(paginas)
                            .comIdioma(request.getParameter("txtidioma"))
                            .comPreco(preco)
                            .comQuantidade(qtd)
                            .comStatus(StatusLivro.valueOf(request.getParameter("selstatus")))
                            .build();
                        dao.atualizar(livro);
                        msg = "Livro atualizado com sucesso.";
                    }
                } catch (NumberFormatException ex) {
                    msg = "Erro: Ano, Páginas, Preço e Quantidade devem ser números válidos.";
                } catch (SQLException ex) {
                    msg = "Erro ao atualizar livro: " + ex.getMessage();
                }
            }
        }

        request.getSession().setAttribute("msg", msg);
        response.sendRedirect("livros.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { processRequest(request, response); }
    @Override
    public String getServletInfo() { return "Servlet ManterLivro - BiblioTech"; }
}
